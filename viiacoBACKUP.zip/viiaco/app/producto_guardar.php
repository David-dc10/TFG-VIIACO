<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario'] !== 'admin') {
    die("Acceso denegado");
}

function subirImagen($campo, $actual = null) {
    if (!isset($_FILES[$campo]) || $_FILES[$campo]['error'] !== UPLOAD_ERR_OK) {
        return $actual; // No hay nueva imagen
    }

    $ext = pathinfo($_FILES[$campo]['name'], PATHINFO_EXTENSION);
    $nombre = uniqid('img_', true) . '.' . $ext;
    $destino = __DIR__ . "/uploads/$nombre";

    if (move_uploaded_file($_FILES[$campo]['tmp_name'], $destino)) {
        return $nombre;
    }

    return $actual;
}

$nombre = trim($_POST['nombre']);
$descripcion = trim($_POST['descripcion']);
$precio = floatval($_POST['precio']);
$stock = intval($_POST['stock']);
$imagen = null;

// EDICIÓN
if (!empty($_POST['id'])) {
    $id = intval($_POST['id']);

    // Obtener imagen actual
    $stmt = $conexion->prepare("SELECT imagen FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $actual = $res->fetch_assoc();
    $imagenActual = $actual['imagen'] ?? null;

    // Subir nueva imagen si la hay
    $imagen = subirImagen('imagen', $imagenActual);

    // Actualizar producto
    $stmt = $conexion->prepare("UPDATE productos SET nombre=?, descripcion=?, precio=?, stock=?, imagen=? WHERE id=?");
    $stmt->bind_param("ssdisi", $nombre, $descripcion, $precio, $stock, $imagen, $id);
    $stmt->execute();
    $_SESSION['success'] = "Producto actualizado correctamente.";
} else {
    // NUEVO producto
    $imagen = subirImagen('imagen');
    $stmt = $conexion->prepare("INSERT INTO productos (nombre, descripcion, precio, stock, imagen) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdiss", $nombre, $descripcion, $precio, $stock, $imagen);
    $stmt->execute();
    $_SESSION['success'] = "Producto creado correctamente.";
}

header("Location: inventario.php");
exit;
