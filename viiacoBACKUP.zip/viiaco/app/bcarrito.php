<?php
session_start();
include 'conexion.php';

$carrito = &$_SESSION['carrito'];
if (!is_array($carrito)) {
    $carrito = [];
}

// Procesar acciones del carrito: actualizar cantidad o eliminar ítem
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);

    if (isset($_POST['action']) && $_POST['action'] === 'update') {
        // Actualizar cantidad
        $qty = max(1, intval($_POST['cantidad'] ?? 1));
        $carrito[$id] = $qty;
    } elseif (isset($_POST['action']) && $_POST['action'] === 'remove') {
        // Eliminar del carrito
        unset($carrito[$id]);
    }

    // Si el carrito queda vacío, deshar referencia
    if (empty($carrito)) {
        unset($_SESSION['carrito']);
    }

    // Redirigir para evitar reenvío de formulario
    header('Location: carrito.php');
    exit;
}

include 'includes/header.php';
?>

<h2>Carrito</h2>

<?php if (empty($carrito)): ?>
  <p>Tu carrito está vacío.</p>
<?php else: ?>
  <table class="table">
    <thead>
      <tr>
        <th>Producto</th>
        <th style="width:120px">Cant.</th>
        <th>Precio U.</th>
        <th>Subtotal</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    <?php
      // Sacamos datos de los productos en el carrito
      $ids = array_keys($carrito);
      $in  = implode(',', array_fill(0, count($ids), '?'));
      $stmt = $conexion->prepare("SELECT id, nombre, precio FROM productos WHERE id IN ($in)");
      $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
      $stmt->execute();
      $res = $stmt->get_result();
      $total = 0;
      while ($p = $res->fetch_assoc()):
        $qty = $carrito[$p['id']];
        $sub = $p['precio'] * $qty;
        $total += $sub;
    ?>
      <tr>
        <td><?= htmlspecialchars($p['nombre']) ?></td>
        <td>
          <!-- Form para actualizar cantidad -->
          <form method="post" action="carrito.php" class="d-flex">
            <input type="hidden" name="id" value="<?= $p['id'] ?>">
            <input type="hidden" name="action" value="update">
            <input type="number" 
                   name="cantidad" 
                   class="form-control form-control-sm me-1" 
                   value="<?= $qty ?>" 
                   min="1">
            <button class="btn btn-sm btn-outline-primary">OK</button>
          </form>
        </td>
        <td><?= number_format($p['precio'],2) ?> €</td>
        <td><?= number_format($sub,2) ?> €</td>
        <td class="text-end">
          <!-- Form para eliminar del carrito -->
          <form method="post" action="carrito.php">
            <input type="hidden" name="id" value="<?= $p['id'] ?>">
            <input type="hidden" name="action" value="remove">
            <button class="btn btn-sm btn-danger">&times;</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
      <tr>
        <th colspan="3" class="text-end">Total:</th>
        <th><?= number_format($total,2) ?> €</th>
        <th></th>
      </tr>
    </tbody>
  </table>

  <a href="confirmar.php" class="btn btn-success">Confirmar Pedido</a>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
