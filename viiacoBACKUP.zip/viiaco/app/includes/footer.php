</main>

<!-- Bootstrap CSS & JS (si no está ya en el header) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Toasts de éxito y error -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
  <?php if (!empty($_SESSION['success_cart'])): ?>
    <div id="toastSuccess" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body">
          <?= htmlspecialchars($_SESSION['success_cart']) ?>
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>
    <?php unset($_SESSION['success_cart']); ?>
  <?php endif; ?>

  <?php if (!empty($_SESSION['error_cart'])): ?>
    <div id="toastError" class="toast align-items-center text-bg-danger border-0" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body">
          <?= htmlspecialchars($_SESSION['error_cart']) ?>
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>
    <?php unset($_SESSION['error_cart']); ?>
  <?php endif; ?>
</div>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const ts = document.getElementById('toastSuccess');
    if (ts) new bootstrap.Toast(ts).show();
    const te = document.getElementById('toastError');
    if (te) new bootstrap.Toast(te).show();
  });
</script>
</body>
</html>
