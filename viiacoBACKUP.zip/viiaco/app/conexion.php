<?php
$host = 'mariadb';
$db = getenv('MARIADB_DATABASE');
$user = getenv('MARIADB_USER');
$pass = getenv('MARIADB_PASSWORD');

$conexion = new mysqli($host, $user, $pass, $db);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>
