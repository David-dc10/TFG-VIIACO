<?php
session_start();
include 'conexion.php'; // Conexión MySQL

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario']);
    $clave   = $_POST['clave'];

    $ldapconn = ldap_connect("ldap://openldap");
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);

    if ($ldapconn) {
        $base_dn = 'dc=viiaco,dc=local';
        $user_dn = "uid=$usuario,ou=usuarios,$base_dn";

        if (@ldap_bind($ldapconn, $user_dn, $clave)) {
            $_SESSION['usuario'] = $usuario;

            // Buscar atributos del usuario
            $filtro = "(uid=$usuario)";
            $busqueda = @ldap_search($ldapconn, "ou=usuarios,$base_dn", $filtro);

if (!$busqueda) {
    $_SESSION['error'] = "Error al buscar atributos del usuario.";
ldap_unbind($ldapconn);    
header("Location: login.php");
    exit;
}

            $entradas = ldap_get_entries($ldapconn, $busqueda);

            if ($entradas["count"] > 0) {
                $entry = $entradas[0];

                $nombre   = $entry["cn"][0]      ?? '';
                $apellido = $entry["sn"][0]      ?? '';
                $email    = $entry["mail"][0]    ?? '';

                // Guardar solo si no existe
                $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE uid = ?");
                $stmt->bind_param("s", $usuario);
                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows === 0) {
                    $stmt->close();
                    $stmt = $conexion->prepare("INSERT INTO usuarios (uid, nombre, apellido, email) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssss", $usuario, $nombre, $apellido, $email);
                    $stmt->execute();
                }
                $stmt->close();
            }

            ldap_unbind($ldapconn);
            header("Location: index.php");
            exit;
        } else {
            $_SESSION['error'] = "Usuario o contraseña incorrectos.";
        }
    } else {
        $_SESSION['error'] = "No se pudo conectar al servidor LDAP.";
    }
    ldap_unbind($ldapconn);
    header("Location: login.php");
    exit;
}

include 'includes/header.php';
?>

<h2>Iniciar sesión</h2>

<?php if (isset($_SESSION['error'])): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
  <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<form method="post" action="login.php">
  <div class="mb-3">
    <label for="usuario" class="form-label">Usuario</label>
    <input type="text" name="usuario" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="clave" class="form-label">Contraseña</label>
    <input type="password" name="clave" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-primary">Acceder</button>
</form>

<?php include 'includes/footer.php'; ?>
