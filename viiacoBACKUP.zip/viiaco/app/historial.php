<?php
session_start();
if (empty($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}
include 'conexion.php';

$usuario = $_SESSION['usuario'];
// obtener pedidos
$stmt = $conexion->prepare("
    SELECT id, fecha, contenido
    FROM pedidos
    WHERE id_usuario = ?
    ORDER BY fecha DESC
");
$stmt->bind_param("s", $usuario);
$stmt->execute();
$pedidos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

include 'includes/header.php';
?>

<h2>Historial de compras</h2>
<?php if (empty($pedidos)): ?>
  <p>No tienes pedidos todavía.</p>
<?php else: ?>
  <?php foreach ($pedidos as $p):
    // decodificar JSON y normalizar a [id=>qty]
    $raw = json_decode($p['contenido'], true);
    if (array_keys($raw) === range(0, count($raw)-1)) {
      // formato antiguo: lista de IDs
      $items = [];
      foreach ($raw as $pid) {
        $items[$pid] = ($items[$pid] ?? 0) + 1;
      }
    } else {
      $items = $raw;
    }

    // recuperar datos de productos
    $ids = array_keys($items);
    if (empty($ids)) continue;
    $in = implode(',', array_fill(0, count($ids), '?'));
    $stmtP = $conexion->prepare("SELECT id, nombre, precio FROM productos WHERE id IN ($in)");
    $stmtP->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmtP->execute();
    $resP = $stmtP->get_result();
    $prodData = [];
    while ($row = $resP->fetch_assoc()) {
      $prodData[$row['id']] = $row;
    }
    $stmtP->close();
  ?>
    <div class="card mb-3">
      <div class="card-header">
        Pedido #<?= htmlspecialchars($p['id']) ?> — <?= htmlspecialchars($p['fecha']) ?>
      </div>
      <ul class="list-group list-group-flush">
        <?php
          $subtotal = 0;
          foreach ($items as $idProd => $qty):
            if (!isset($prodData[$idProd])) continue;
            $prod = $prodData[$idProd];
            $sub  = $prod['precio'] * $qty;
            $subtotal += $sub;
        ?>
          <li class="list-group-item d-flex justify-content-between">
            <?= htmlspecialchars($prod['nombre']) ?> x <?= $qty ?>
            <span><?= number_format($sub,2) ?> €</span>
          </li>
        <?php endforeach; ?>
        <li class="list-group-item d-flex justify-content-between fw-bold">
          Total pedido:
          <span><?= number_format($subtotal,2) ?> €</span>
        </li>
      </ul>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
