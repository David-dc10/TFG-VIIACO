<?php
session_start();
include 'conexion.php';
include 'includes/header.php';

$id = intval($_GET['id'] ?? 0);
$producto = null;
if ($id > 0) {
    $stmt = $conexion->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
?>

<div class="container my-5">
  <?php if ($producto): ?>
    <div class="row g-4 align-items-start">
      <div class="col-md-6 text-center">
        <img src="/uploads/<?= htmlspecialchars($producto['imagen']) ?>" 
             class="img-fluid rounded shadow-sm" 
             alt="<?= htmlspecialchars($producto['nombre']) ?>" 
             style="max-height: 400px; object-fit: contain;">
      </div>

      <div class="col-md-6">
        <h2 class="fw-bold mb-3"><?= htmlspecialchars($producto['nombre']) ?></h2>
        <p class="mb-4"><?= nl2br(htmlspecialchars($producto['descripcion'])) ?></p>
        <p class="fs-4 text-primary fw-semibold"><?= number_format($producto['precio'], 2) ?> €</p>

        <form method="post" action="/carrito.php" id="add-to-cart-form" class="mt-4">
          <input type="hidden" name="action" value="add">
          <input type="hidden" name="id" value="<?= $producto['id'] ?>">

          <div class="input-group mb-3" style="max-width: 200px;">
            <input type="number" name="cantidad" class="form-control" value="1" min="1">
            <button class="btn btn-primary" type="submit">Añadir al carrito</button>
          </div>
        </form>

        <a href="catalogo.php" class="btn btn-outline-secondary mt-2">Volver al catálogo</a>
      </div>
    </div>
  <?php else: ?>
    <div class="alert alert-warning text-center">Producto no encontrado.</div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
