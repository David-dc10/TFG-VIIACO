<?php
session_start();
include 'conexion.php'; // Conexión MySQL

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario']);
    $clave   = $_POST['clave'];

    $ldapconn = ldap_connect("ldap://openldap");
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);

    if ($ldapconn) {
        $base_dn = 'dc=viiaco,dc=local';
        $user_dn = "uid=$usuario,ou=usuarios,$base_dn";

        if (@ldap_bind($ldapconn, $user_dn, $clave)) {
            $_SESSION['usuario'] = $usuario;

            // Buscar atributos del usuario
            $filtro = "(uid=$usuario)";
            $busqueda = @ldap_search($ldapconn, "ou=usuarios,$base_dn", $filtro);

            // Valores por defecto
            $nombre = '';
            $apellido = '';
            $email = '';

            if ($busqueda) {
                $entradas = ldap_get_entries($ldapconn, $busqueda);
                if ($entradas["count"] > 0) {
                    $entry = $entradas[0];
                    $nombre   = $entry["cn"][0]   ?? '';
                    $apellido = $entry["sn"][0]   ?? '';
                    $email    = $entry["mail"][0] ?? '';
                }
            }

            // Guardar siempre si no existe
            $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE uid = ?");
            $stmt->bind_param("s", $usuario);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 0) {
                $stmt->close();
                $stmt = $conexion->prepare("INSERT INTO usuarios (uid, nombre, apellido, email) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $usuario, $nombre, $apellido, $email);
                $stmt->execute();
            } else {
                $stmt->close();
            }

            ldap_unbind($ldapconn);
            header("Location: index.php");
            exit;
        } else {
            $_SESSION['error'] = "Usuario o contraseña incorrectos.";
        }

        ldap_unbind($ldapconn);
    } else {
        $_SESSION['error'] = "No se pudo conectar al servidor LDAP.";
    }

    header("Location: login.php");
    exit;
}

include 'includes/header.php';
?>

<div class="container my-5" style="max-width: 400px;">
  <h2 class="mb-4 text-center">Iniciar sesión</h2>

  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($_SESSION['error']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
  <?php endif; ?>

  <form method="post" action="login.php" novalidate>
    <div class="mb-3">
      <label for="usuario" class="form-label">Usuario</label>
      <input type="text" id="usuario" name="usuario" class="form-control" required autofocus>
    </div>
    <div class="mb-3">
      <label for="clave" class="form-label">Contraseña</label>
      <input type="password" id="clave" name="clave" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary w-100">Acceder</button>
  </form>
</div>

<?php include 'includes/footer.php'; ?>
