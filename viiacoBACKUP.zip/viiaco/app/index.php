<?php include 'includes/header.php'; ?>
<section class="position-relative text-white" style="background: url('assets/banner.jpg') center/cover no-repeat; height: 400px;">
  <div class="container h-100 d-flex flex-column justify-content-center align-items-center text-center" style="background-color: rgba(0,0,0,0.5);">
    <h1 class="display-4 fw-bold">WELCOME to VIIACO</h1>
    <p class="lead mb-4">WEAR YOUR NEW FAVORITE</p>
    <a href="catalogo.php" class="btn btn-lg btn-light shadow">Explorar catálogo</a>
  </div>
</section>

<section class="container my-5">
  <div class="row text-center">
    <div class="col-md-4 mb-4">
      <div class="card h-100 border-0 shadow-sm">
        <div class="card-body">
          <i class="bi bi-box-seam display-4 text-primary mb-3"></i>
          <h5 class="card-title">Productos de calidad</h5>
          <p class="card-text">Seleccionamos cuidadosamente cada producto para ofrecerte lo mejor.</p>
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-4">
      <div class="card h-100 border-0 shadow-sm">
        <div class="card-body">
          <i class="bi bi-truck display-4 text-primary mb-3"></i>
          <h5 class="card-title">Envíos rápidos</h5>
          <p class="card-text">Recibe tu pedido en tiempo récord, donde lo necesites.(Solo en ESPAÑA)</p>
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-4">
      <div class="card h-100 border-0 shadow-sm">
        <div class="card-body">
          <i class="bi bi-shield-check display-4 text-primary mb-3"></i>
          <h5 class="card-title">Calidad garantizada</h5>
          <p class="card-text">Solo colaboramos con los mejores proveedores europeos.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="bg-primary text-white py-5">
  <div class="container text-center">
    <h2 class="mb-4">¿Listo para encontrar algo especial?</h2>
    <a href="catalogo.php" class="btn btn-outline-light btn-lg">Ver productos destacados</a>
  </div>
</section>

<section class="container my-5">
  <h3 class="text-center mb-4">Lo que dicen nuestros clientes</h3>
  <div class="row">
    <div class="col-md-4 mb-4">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-body">
          <p class="card-text">"Excelente experiencia. Envío rápido y producto perfecto."</p>
          <h6 class="card-subtitle text-muted">– María G.</h6>
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-4">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-body">
          <p class="card-text">"Atención al cliente de primera. Volveré a comprar sin duda."</p>
          <h6 class="card-subtitle text-muted">– Jorge L.</h6>
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-4">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-body">
          <p class="card-text">"La web es muy fácil de usar, y el catálogo es variado."</p>
          <h6 class="card-subtitle text-muted">– Ana P.</h6>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="bg-light py-5">
  <div class="container text-center">
    <h4 class="mb-4">MADE IN SPAIN</h4>
    <div class="d-flex justify-content-center flex-wrap gap-4">
      <img src="assets/marca1.png" alt="Marca 1" style="height: 50px;">
      <img src="assets/marca2.png" alt="Marca 2" style="height: 50px;">
      <img src="assets/marca3.png" alt="Marca 3" style="height: 50px;">
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
