<?php
session_start();
include 'conexion.php';
include 'includes/header.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario'] !== 'admin') {
    echo "<div class='alert alert-danger'>Acceso denegado. Solo el administrador puede ver esta página.</div>";
    include 'includes/footer.php';
    exit;
}

$producto = [
    'id' => '',
    'nombre' => '',
    'descripcion' => '',
    'precio' => '',
    'stock' => '',
    'imagen' => ''
];

$editando = false;

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conexion->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $producto = $res->fetch_assoc();
    $editando = true;
    $stmt->close();
}
?>

<div class="container mt-4">
  <h2><?= $editando ? 'Editar Producto' : 'Nuevo Producto' ?></h2>

  <form action="producto_guardar.php" method="post" enctype="multipart/form-data">
    <?php if ($editando): ?>
      <input type="hidden" name="id" value="<?= $producto['id'] ?>">
    <?php endif; ?>

    <div class="mb-3">
      <label for="nombre" class="form-label">Nombre</label>
      <input type="text" name="nombre" id="nombre" class="form-control" required value="<?= htmlspecialchars($producto['nombre']) ?>">
    </div>

    <div class="mb-3">
      <label for="descripcion" class="form-label">Descripción</label>
      <textarea name="descripcion" id="descripcion" class="form-control" rows="3"><?= htmlspecialchars($producto['descripcion']) ?></textarea>
    </div>

    <div class="mb-3">
      <label for="precio" class="form-label">Precio (€)</label>
      <input type="number" name="precio" id="precio" class="form-control" step="0.01" required value="<?= htmlspecialchars($producto['precio']) ?>">
    </div>

    <div class="mb-3">
      <label for="stock" class="form-label">Stock disponible</label>
      <input type="number" name="stock" id="stock" class="form-control" required value="<?= htmlspecialchars($producto['stock']) ?>">
    </div>

    <div class="mb-3">
      <label for="imagen" class="form-label">Imagen</label>
      <input type="file" name="imagen" id="imagen" class="form-control">
      <?php if ($editando && $producto['imagen']): ?>
        <p class="mt-2">Imagen actual: <img src="/uploads/<?= htmlspecialchars($producto['imagen']) ?>" alt="" style="height: 60px;"></p>
      <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-success"><?= $editando ? 'Actualizar' : 'Crear' ?> Producto</button>
    <a href="inventario.php" class="btn btn-secondary">Cancelar</a>
  </form>
</div>

<?php include 'includes/footer.php'; ?>
