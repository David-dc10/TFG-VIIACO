<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];

    $ldapconn = ldap_connect("ldap://openldap");
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);

    if ($ldapconn) {
        $base_dn = getenv('LDAP_BASE_DN') ?: 'dc=viiaco,dc=local'; // fallback por si no se carga .env
        $user_dn = "uid=$usuario,ou=usuarios,$base_dn";

        if (@ldap_bind($ldapconn, $user_dn, $clave)) {
            $_SESSION['usuario'] = $usuario;
            header("Location: index.php");
            exit;
        } else {
            $_SESSION['error'] = "Usuario o contraseña incorrectos.";
            header("Location: login.php");
            exit;
        }
    }
}

include 'includes/header.php';
?>

<h2>Iniciar sesión</h2>
<?php if (isset($_SESSION['error'])): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
  <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<form method="post" action="login.php">
  <div class="mb-3">
    <label for="usuario" class="form-label">Usuario</label>
    <input type="text" name="usuario" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="clave" class="form-label">Contraseña</label>
    <input type="password" name="clave" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-primary">Acceder</button>
</form>

<?php include 'includes/footer.php'; ?>
