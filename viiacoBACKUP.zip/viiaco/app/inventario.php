<?php
session_start();
include 'conexion.php';

if (empty($_SESSION['usuario']) || $_SESSION['usuario'] !== 'Admin') {
    header('Location: index.php');
    exit;
}

// Procesar alta o edición
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idProd = intval($_POST['id'] ?? 0);
    $nombre = $_POST['nombre'] ?? '';
    $descripcion = $_POST['descripcion'] ?? '';
    $precio = floatval($_POST['precio'] ?? 0);
    $stock  = intval($_POST['stock'] ?? 0);
    $imagen = null;

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
        $fn  = uniqid('prod_', true) . '.' . $ext;
        $dst = __DIR__ . '/uploads/' . $fn;
        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $dst)) {
            $imagen = $fn;
        }
    }

    if ($idProd > 0) {
        if ($imagen) {
            $stmt = $conexion->prepare("
              UPDATE productos 
              SET nombre=?, descripcion=?, precio=?, stock=?, imagen=?
              WHERE id=?
            ");
            $stmt->bind_param("ssdssi", $nombre, $descripcion, $precio, $stock, $imagen, $idProd);
        } else {
            $stmt = $conexion->prepare("
              UPDATE productos 
              SET nombre=?, descripcion=?, precio=?, stock=?
              WHERE id=?
            ");
            $stmt->bind_param("ssdsi", $nombre, $descripcion, $precio, $stock, $idProd);
        }
        $_SESSION['success'] = "Producto actualizado correctamente.";
    } else {
        $stmt = $conexion->prepare("
          INSERT INTO productos (nombre, descripcion, precio, stock, imagen)
          VALUES (?, ?, ?, ?, ?)
        ");
$stmt->bind_param("ssdss", $nombre, $descripcion, $precio, $stock, $imagen);

        $_SESSION['success'] = "Producto añadido correctamente.";
    }
    $stmt->execute();
    $stmt->close();

    header("Location: inventario.php");
    exit;
}

if (isset($_GET['delete'])) {
    $delId = intval($_GET['delete']);
    $conexion->query("DELETE FROM productos WHERE id = {$delId}");
    $_SESSION['success'] = "Producto eliminado.";
    header("Location: inventario.php");
    exit;
}

include 'includes/header.php';
?>

<div class="container py-4">
  <h2 class="mb-4">🛠 Gestión de Inventario</h2>

  <?php if (!empty($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($_SESSION['success']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
  <?php endif; ?>

  <!-- Lista -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0">📦 Productos actuales</h5>
    </div>
    <div class="card-body">
      <table class="table table-striped table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Imagen</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
        <?php
          $res = $conexion->query("SELECT * FROM productos ORDER BY id DESC");
          while ($p = $res->fetch_assoc()):
        ?>
          <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['nombre']) ?></td>
            <td><?= number_format($p['precio'], 2) ?> €</td>
            <td><?= $p['stock'] ?></td>
            <td>
              <?php if ($p['imagen']): ?>
                <img src="uploads/<?= htmlspecialchars($p['imagen']) ?>" style="height:40px" class="rounded shadow-sm">
              <?php endif; ?>
            </td>
            <td>
              <a href="inventario.php?edit=<?= $p['id'] ?>" class="btn btn-sm btn-warning">✎ Editar</a>
              <a href="inventario.php?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger"
                 onclick="return confirm('¿Eliminar producto?')">🗑 Eliminar</a>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Formulario Alta/Edición -->
  <?php
    $editing = false;
    if (isset($_GET['edit'])) {
      $eid = intval($_GET['edit']);
      $row = $conexion->query("SELECT * FROM productos WHERE id={$eid}")->fetch_assoc();
      if ($row) $editing = true;
    }
  ?>
  <div class="card shadow-sm">
    <div class="card-header bg-success text-white">
      <h5 class="mb-0"><?= $editing ? "✏️ Editar producto" : "➕ Añadir producto" ?></h5>
    </div>
    <div class="card-body">
      <form method="POST" enctype="multipart/form-data">
        <?php if ($editing): ?>
          <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <?php endif; ?>
        <div class="mb-3">
          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" class="form-control" required
                 value="<?= $editing ? htmlspecialchars($row['nombre']) : '' ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Descripción</label>
          <textarea name="descripcion" class="form-control" rows="3"><?= $editing ? htmlspecialchars($row['descripcion']) : '' ?></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label">Precio (€)</label>
          <input type="number" step="0.01" name="precio" class="form-control" required
                 value="<?= $editing ? $row['precio'] : '' ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Stock</label>
          <input type="number" name="stock" class="form-control" required
                 value="<?= $editing ? $row['stock'] : '0' ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Imagen</label>
          <input type="file" name="imagen" accept="image/*" class="form-control">
          <?php if ($editing && $row['imagen']): ?>
            <small class="text-muted">Imagen actual: <?= htmlspecialchars($row['imagen']) ?></small>
          <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-success">
          <?= $editing ? "💾 Guardar cambios" : "➕ Añadir producto" ?>
        </button>
      </form>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
