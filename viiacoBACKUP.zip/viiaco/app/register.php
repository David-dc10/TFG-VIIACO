<?php
session_start();
$error = '';
function ldap_hash_password($password) {
    $salt = substr(str_shuffle('./ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'), 0, 16);
    return '{CRYPT}' . crypt($password, '$6$' . $salt); // SHA-512
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid   = trim($_POST['usuario']);
    $cn    = trim($_POST['nombre']);
    $sn    = trim($_POST['apellido']);
    $mail  = trim($_POST['email']);
    $pass  = $_POST['clave'];

    if (!$uid || !$cn || !$sn || !$mail || !$pass) {
        $error = "Todos los campos son obligatorios.";
    } elseif (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        $error = "Correo electrónico no válido.";
    } elseif (strlen($pass) < 6) {
        $error = "La contraseña debe tener al menos 6 caracteres.";
    } else {
        $ldapconn = ldap_connect("ldap://openldap");
        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);

        $adminDn   = "cn=admin," . getenv('LDAP_BASE_DN');
        $adminPass = getenv('LDAP_ADMIN_PASSWORD');

        if (@ldap_bind($ldapconn, $adminDn, $adminPass)) {
            $hashedPassword = ldap_hash_password($pass);

            $entry = [
                "objectClass"   => ["inetOrgPerson", "organizationalPerson", "person", "top"],
                "uid"           => $uid,
                "cn"            => $cn,
                "sn"            => $sn,
                "mail"          => $mail,
                "userPassword"  => $hashedPassword
            ];

            $dn = "uid={$uid},ou=usuarios," . getenv('LDAP_BASE_DN');

            if (@ldap_add($ldapconn, $dn, $entry)) {
                $_SESSION['mensaje'] = "Usuario registrado correctamente. Por favor, inicia sesión.";
                ldap_unbind($ldapconn);
                header("Location: login.php");
                exit;
            } else {
                $error = "Error al registrar en LDAP: " . ldap_error($ldapconn);
            }
        } else {
            $error = "No se pudo conectar como administrador LDAP.";
        }

        ldap_unbind($ldapconn);
    }
}

include "includes/header.php";
?>

<div class="container my-5" style="max-width: 480px;">
  <h2 class="mb-4 text-center">Crear cuenta</h2>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($error) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
  <?php endif; ?>

  <form method="post" action="register.php" novalidate>
    <input name="usuario"    required placeholder="Usuario (uid)" class="form-control mb-3" autofocus>
    <input name="nombre"     required placeholder="Nombre" class="form-control mb-3">
    <input name="apellido"   required placeholder="Apellidos" class="form-control mb-3">
    <input name="email"      type="email" required placeholder="Correo electrónico" class="form-control mb-3">
    <input type="password" name="clave" required placeholder="Contraseña" class="form-control mb-4">
    <button class="btn btn-success w-100" type="submit">Registrarse</button>
  </form>
</div>

<?php include "includes/footer.php"; ?>
