<?php
include 'conexion.php';
include 'includes/header.php';

$resultado = $conexion->query("SELECT * FROM productos");
?>
<div class="container my-5">
  <h2 class="mb-5 text-center display-5">Catálogo de productos</h2>
  <div class="row row-cols-1 row-cols-md-2 g-5">
    <?php while ($producto = $resultado->fetch_assoc()): ?>
      <div class="col">
        <div class="card h-100 shadow-lg rounded-4 border-0 overflow-hidden">
          <div style="height: 400px; overflow: hidden;">
            <img src="uploads/<?php echo htmlspecialchars($producto['imagen']); ?>"
                 class="card-img-top"
                 alt="Producto"
                 style="object-fit: contain; width: 100%; height: 100%; background-color: #f8f9fa;">
          </div>

          <div class="card-body d-flex flex-column p-4">
            <h5 class="card-title fs-4"><?php echo htmlspecialchars($producto['nombre']); ?></h5>
            <p class="card-text text-muted flex-grow-1"><?php echo htmlspecialchars($producto['descripcion']); ?></p>
            <p class="fw-bold fs-5 text-primary"><?php echo number_format($producto['precio'], 2); ?> €</p>
          </div>

          <div class="card-footer bg-white border-0 p-4 pt-0 text-center">
            <a href="detalle.php?id=<?php echo $producto['id']; ?>" class="btn btn-primary w-100 rounded-pill">
              Ver más
            </a>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
