<?php
session_start();
include 'conexion.php';

$carrito = &$_SESSION['carrito'];
if (!is_array($carrito)) {
    $carrito = [];
}

// 👉 Añadir producto
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['eliminar'])) {
        $id = intval($_POST['eliminar']);
        unset($carrito[$id]);
        $_SESSION['success_cart'] = "Producto eliminado del carrito.";
        header("Location: carrito.php");
        exit;
    }

    $id  = intval($_POST['id']);
    $qty = max(1, intval($_POST['cantidad'] ?? 1));

    $stmt = $conexion->prepare("SELECT stock FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stock = $stmt->get_result()->fetch_assoc()['stock'] ?? 0;
    $stmt->close();

    $enCarrito = $carrito[$id] ?? 0;
    if ($enCarrito + $qty > $stock) {
        $_SESSION['error_cart'] = "No hay suficiente stock para ese producto.";
    } else {
        $carrito[$id] = $enCarrito + $qty;
        $_SESSION['success_cart'] = "Producto añadido al carrito.";
    }

    header("Location: " . ($_SERVER['HTTP_REFERER'] ?? '/catalogo.php'));
    exit;
}

include 'includes/header.php';
?>

<div class="container my-5">
  <h2 class="mb-4 text-center">Tu carrito</h2>

  <?php if (!empty($_SESSION['success_cart'])): ?>
    <div class="alert alert-success text-center"><?= $_SESSION['success_cart']; unset($_SESSION['success_cart']); ?></div>
  <?php elseif (!empty($_SESSION['error_cart'])): ?>
    <div class="alert alert-danger text-center"><?= $_SESSION['error_cart']; unset($_SESSION['error_cart']); ?></div>
  <?php endif; ?>

  <?php if (empty($carrito)): ?>
    <div class="alert alert-info text-center">Tu carrito está vacío.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-bordered align-middle text-center">
        <thead class="table-dark">
          <tr>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio unitario</th>
            <th>Subtotal</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $ids = array_keys($carrito);
          $in  = implode(',', array_fill(0, count($ids), '?'));
          $stmt = $conexion->prepare("SELECT id, nombre, precio FROM productos WHERE id IN ($in)");
          $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
          $stmt->execute();
          $res = $stmt->get_result();
          $total = 0;
          while ($p = $res->fetch_assoc()):
            $qty = $carrito[$p['id']];
            $sub = $p['precio'] * $qty;
            $total += $sub;
          ?>
          <tr>
            <td><?= htmlspecialchars($p['nombre']) ?></td>
            <td><?= $qty ?></td>
            <td><?= number_format($p['precio'], 2) ?> €</td>
            <td><?= number_format($sub, 2) ?> €</td>
            <td>
              <form method="post" class="d-inline">
                <input type="hidden" name="eliminar" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-outline-danger">Eliminar</button>
              </form>
            </td>
          </tr>
          <?php endwhile; ?>
          <tr>
            <th colspan="4" class="text-end">Total:</th>
            <th class="text-success"><?= number_format($total, 2) ?> €</th>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="text-center mt-4">
      <a href="/confirmar.php" class="btn btn-success btn-lg px-5">Confirmar Pedido</a>
    </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
