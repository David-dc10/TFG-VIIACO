<?php
session_start();
include 'conexion.php';

$carrito = $_SESSION['carrito'] ?? [];
if (empty($carrito)) {
    header('Location: carrito.php');
    exit;
}

// 1) Validar stock de todos los ítems
foreach ($carrito as $id => $qty) {
    $stmt = $conexion->prepare("SELECT stock FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stock = $stmt->get_result()->fetch_assoc()['stock'] ?? 0;
    $stmt->close();

    if ($qty > $stock) {
        $_SESSION['error_cart'] = "No hay suficiente stock para el producto #{$id} (solo {$stock}).";
        header('Location: carrito.php');
        exit;
    }
}

// 2) Validar usuario autenticado y existente en la base de datos
$usuario = trim($_SESSION['usuario'] ?? '');
if (empty($usuario)) {
    // Mostrar alerta y no continuar, evitando error en blanco
    include 'includes/header.php';
    ?>
    <div class="container my-5">
      <div class="alert alert-warning text-center" role="alert">
        Debes <a href="login.php" class="alert-link">iniciar sesión</a> para poder confirmar tu pedido.
      </div>
      <div class="text-center mt-3">
        <a href="carrito.php" class="btn btn-secondary">Volver al carrito</a>
      </div>
    </div>
    <?php
    include 'includes/footer.php';
    exit;
}

$stmt = $conexion->prepare("SELECT uid FROM usuarios WHERE uid = ?");
$stmt->bind_param("s", $usuario);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $stmt->close();
    include 'includes/header.php';
    ?>
    <div class="container my-5">
      <div class="alert alert-danger text-center" role="alert">
        Usuario no existe en la base de datos. Por favor, contacta con soporte.
      </div>
      <div class="text-center mt-3">
        <a href="carrito.php" class="btn btn-secondary">Volver al carrito</a>
      </div>
    </div>
    <?php
    include 'includes/footer.php';
    exit;
}
$stmt->close();

// 3) Insertar pedido
$contenido = json_encode($carrito);
$stmt = $conexion->prepare(
    "INSERT INTO pedidos (id_usuario, contenido) VALUES (?, ?)"
);
$stmt->bind_param("ss", $usuario, $contenido);
$stmt->execute();
$stmt->close();

// 4) Reducir stock
foreach ($carrito as $id => $qty) {
    $stmt = $conexion->prepare(
        "UPDATE productos SET stock = stock - ? WHERE id = ?"
    );
    $stmt->bind_param("ii", $qty, $id);
    $stmt->execute();
    $stmt->close();
}

// 5) Vaciar carrito y mostrar éxito
$_SESSION['success_cart'] = "Pedido confirmado correctamente.";
unset($_SESSION['carrito']);

header('Location: index.php');
exit;
