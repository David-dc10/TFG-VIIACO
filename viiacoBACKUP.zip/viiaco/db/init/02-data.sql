-- 02-data.sql
USE `viiaco`;

INSERT INTO productos (nombre, descripcion, precio, imagen) VALUES
  ('Camiseta Negra', 'Camiseta básica negra de algodón', 14.95, 'camiseta-negra.jpg'),
  ('Sudadera Gris', 'Sudadera unisex con capucha',        29.99, 'sudadera-gris.jpg'),
  ('Mochila Urbana', 'Mochila resistente para diario',     39.50, 'mochila.jpg');
