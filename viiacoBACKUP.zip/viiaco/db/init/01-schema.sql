
-- 01-schema.sql

-- 1) CREA LA BD DE LA APLICACIÓN Y SÉLECCIÓNALA
CREATE DATABASE IF NOT EXISTS `viiaco`;
USE `viiaco`;

-- 2) TABLA DE USUARIOS (solo guardamos el uid LDAP y la fecha de registro)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid VARCHAR(50) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL
);

-- 3) TABLA DE PRODUCTOS
CREATE TABLE IF NOT EXISTS productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT,
  precio DECIMAL(10,2),
  stock INT NOT NULL DEFAULT 0,
  imagen VARCHAR(255)
);



-- 4) TABLA DE PEDIDOS (ahora sí con id_usuario)
CREATE TABLE IF NOT EXISTS pedidos (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario  VARCHAR(100) NOT NULL,
  fecha       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  contenido   TEXT NOT NULL,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(uid)
);

-- 5) (Opcional) BD y usuario de Zabbix
CREATE DATABASE IF NOT EXISTS `zabbix`;
CREATE USER IF NOT EXISTS 'zabbix'@'%' IDENTIFIED BY 'zabbixPass';
GRANT ALL PRIVILEGES ON `zabbix`.* TO 'zabbix'@'%';
